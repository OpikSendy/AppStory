package com.example.appstory.ui.profile

import androidx.appcompat.app.AppCompatActivity

class EditProfileActivity : AppCompatActivity() {

//    private lateinit var binding: ActivityEditProfileBinding
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = ActivityEditProfileBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        binding.btnSave.setOnClickListener {
//            saveProfileChanges()
//        }
//    }
//
//    private fun saveProfileChanges() {
//        val name = binding.etName.text.toString()
//        val email = binding.etEmail.text.toString()
//    }
}
