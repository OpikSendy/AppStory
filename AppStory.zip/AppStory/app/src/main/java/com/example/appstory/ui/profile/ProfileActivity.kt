package com.example.appstory.ui.profile

import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
//    private lateinit var binding: ActivityProfileBinding
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = ActivityProfileBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        val preferences = getSharedPreferences("session", Context.MODE_PRIVATE)
//        binding.tvProfileName.text = preferences.getString("name", "User Name")
//        binding.tvProfileEmail.text = preferences.getString("email", "user@example.com")
//
//        binding.btnEditProfile.setOnClickListener {
//            // Navigasi ke halaman EditProfile
//        }
//
//    }
//
//    private fun toggleDarkMode() {
//        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
//        if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//        } else {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//        }
//    }
}
